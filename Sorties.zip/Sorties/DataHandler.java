package Sorties;
/**
 * This class handles reading/writing data from external source
 * Imagining a .txt file stored on user's PC
 * It will store sortie data, provide sortie data to GUI class,
 * 		possibly encrypt/decrypt or upload sortie data.
 */
public class DataHandler {
	//TODO build DataHandler lol
}
